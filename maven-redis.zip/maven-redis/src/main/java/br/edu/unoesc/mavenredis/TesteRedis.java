package br.edu.unoesc.mavenredis;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.util.JedisURIHelper;

public class TesteRedis {
    public static void main(String[] args) {
        Jedis jedis = new Jedis("localhost", 6379);

        System.out.println(jedis.ping());
        System.out.println(jedis.echo("Olá Redis!\n"));

        System.out.println(jedis.set("universidade", "Unoesc"));
        System.out.println(jedis.get("universidade"));

        if (jedis.del("universidade") == 1) {
            System.out.println("Chave excluida com sucesso!");
        }

        if (jedis.get("universidade") == null) {
            System.out.println("Chave não existe!");
        }

        Map<String, String> aluno = new HashMap<>();
        aluno.put("nome", "Fulano");
        aluno.put("curso", "Computação");
        jedis.hset("aluno:01", aluno);

        System.out.println(jedis.hgetAll("aluno:01"));

        jedis.close();
    }
}